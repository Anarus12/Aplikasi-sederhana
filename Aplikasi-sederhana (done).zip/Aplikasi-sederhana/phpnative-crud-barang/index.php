<!DOCTYPE html>
<html>
<head>
    <title>PHP Native CRUD Barang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Daftar Barang</h2>
    <a href="tambah.php" class="btn btn-primary mb-3">Tambah Barang</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Kode</th><th>Nama</th><th>Deskripsi</th><th>Harga</th><th>Jumlah</th><th>Foto</th><th>Aksi</th>
            </tr>
        </thead>
        <tbody>
        <?php
        include 'config/db.php';
        $data = mysqli_query($conn, "SELECT * FROM barang");
        while($d = mysqli_fetch_array($data)){
            echo "<tr>
                <td>{$d['kode']}</td>
                <td>{$d['nama_barang']}</td>
                <td>{$d['deskripsi']}</td>
                <td>{$d['harga_satuan']}</td>
                <td>{$d['jumlah']}</td>
                <td><img src='uploads/{$d['foto']}' width='60'></td>
                <td>Edit | Hapus</td>
            </tr>";
        }
        ?>
        </tbody>
    </table>
</div>
</body>
</html>
