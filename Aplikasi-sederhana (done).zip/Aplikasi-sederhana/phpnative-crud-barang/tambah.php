<form action="proses_tambah.php" method="post" enctype="multipart/form-data">
    <input type="text" name="kode" placeholder="Kode"><br>
    <input type="text" name="nama_barang" placeholder="Nama Barang"><br>
    <textarea name="deskripsi" placeholder="Deskripsi"></textarea><br>
    <input type="number" name="harga_satuan" placeholder="Harga"><br>
    <input type="number" name="jumlah" placeholder="Jumlah"><br>
    <input type="file" name="foto"><br>
    <button type="submit">Simpan</button>
</form>
