# Aplikasi CRUD Barang

Proyek ini terdiri dari dua versi:
- Laravel CRUD
- PHP Native CRUD

Tabel: barang (kode, nama_barang, deskripsi, harga_satuan, jumlah, foto)
