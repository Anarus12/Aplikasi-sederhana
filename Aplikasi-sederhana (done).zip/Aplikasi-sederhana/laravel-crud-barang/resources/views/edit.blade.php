<!DOCTYPE html>
<html>
<head>
    <title>Edit Barang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Edit Barang</h2>
    <form action="{{ route('barang.update', $barang->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <div class="mb-3"><input type="text" name="kode" class="form-control" value="{{ $barang->kode }}"></div>
        <div class="mb-3"><input type="text" name="nama_barang" class="form-control" value="{{ $barang->nama_barang }}"></div>
        <div class="mb-3"><textarea name="deskripsi" class="form-control">{{ $barang->deskripsi }}</textarea></div>
        <div class="mb-3"><input type="number" name="harga_satuan" class="form-control" value="{{ $barang->harga_satuan }}"></div>
        <div class="mb-3"><input type="number" name="jumlah" class="form-control" value="{{ $barang->jumlah }}"></div>
        <div class="mb-3"><input type="file" name="foto" class="form-control"></div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
</body>
</html>
