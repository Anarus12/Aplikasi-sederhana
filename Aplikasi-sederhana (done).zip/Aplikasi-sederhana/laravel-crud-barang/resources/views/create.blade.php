<!DOCTYPE html>
<html>
<head>
    <title>Tambah Barang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Tambah Barang</h2>
    <form action="{{ route('barang.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="mb-3"><input type="text" name="kode" class="form-control" placeholder="Kode Barang"></div>
        <div class="mb-3"><input type="text" name="nama_barang" class="form-control" placeholder="Nama Barang"></div>
        <div class="mb-3"><textarea name="deskripsi" class="form-control" placeholder="Deskripsi"></textarea></div>
        <div class="mb-3"><input type="number" name="harga_satuan" class="form-control" placeholder="Harga Satuan"></div>
        <div class="mb-3"><input type="number" name="jumlah" class="form-control" placeholder="Jumlah"></div>
        <div class="mb-3"><input type="file" name="foto" class="form-control"></div>
        <button type="submit" class="btn btn-success">Simpan</button>
    </form>
</div>
</body>
</html>
