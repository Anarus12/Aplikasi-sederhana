<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Barang;

class BarangController extends Controller
{
    public function index() {
        $barang = Barang::all();
        return view('index', compact('barang'));
    }

    public function create() {
        return view('create');
    }

    public function store(Request $request) {
        $validated = $request->validate([
            'kode' => 'required',
            'nama_barang' => 'required',
            'deskripsi' => 'required',
            'harga_satuan' => 'required|numeric',
            'jumlah' => 'required|numeric',
            'foto' => 'required|image|mimes:jpg,jpeg,png'
        ]);

        $path = $request->file('foto')->store('barang', 'public');
        $validated['foto'] = $path;

        Barang::create($validated);
        return redirect()->route('barang.index');
    }

    public function edit($id) {
        $barang = Barang::findOrFail($id);
        return view('edit', compact('barang'));
    }

    public function update(Request $request, $id) {
        $barang = Barang::findOrFail($id);
        $data = $request->except(['_token', '_method']);
        if ($request->hasFile('foto')) {
            $data['foto'] = $request->file('foto')->store('barang', 'public');
        }
        $barang->update($data);
        return redirect()->route('barang.index');
    }

    public function destroy($id) {
        $barang = Barang::findOrFail($id);
        $barang->delete();
        return redirect()->route('barang.index');
    }
}
